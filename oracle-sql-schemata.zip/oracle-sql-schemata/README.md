# Oracle-SQL – Tabellenschemata

Ausgewählte DDL-Dateien aus der Datenbankübung. Sie dokumentieren Tabellen, Spaltentypen und Constraints. Für die Ausführung sind eine Oracle-Datenbank und gegebenenfalls die Anpassung vorhandener Schema- und Tablespace-Namen erforderlich.
